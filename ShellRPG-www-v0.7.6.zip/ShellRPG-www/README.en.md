[Deutsch](README.md) | English

🏛️☠️🌿                                                                 🌿☠️🏛️
╔══════════════════════════════════════════════════════════════════════════════╗
║  _/\______________________________________________________________/\\_     ║
║  \_/\\                                                            /\_/     ║
║  /_/\\   U N R O L L E D   S C R O L L                            /\_\     ║
║  \_\/____________________________________________________________\/_/     ║
╚══════════════════════════════════════════════════════════════════════════════╝
# ShellRPG-www · v0.6.7

## 1. Description

**Artifact role:** Public graphical web client for map, movement, character views, inventory, city panels, and system navigation.

**Purpose:** This artifact is the visual sibling interface to the terminal client. It focuses on overview, navigation, and system-facing interaction without bypassing server authority.

**Connected artifacts:**
- `ShellRPG-server` provides all authoritative data.
- `ShellRPG-client` is the shell-first sibling client.
- `ShellRPG-wiki` provides redacted documentation, lore, and usage help.

**Governance:** `CLIENT-PUBLIC`

## 2. Dependencies

- static web server or local file host
- browser with modern JavaScript support
- running `ShellRPG-server` for live data

## 3. Installation

```bash
python -m http.server 8080
```

Then open in your browser:
```text
http://127.0.0.1:8080/public/index.html
```

## 4. Feedback & Contribution

Feedback should mention browser, screen size, and the affected view.
Contribution should prioritize accessibility, readability, and public-scope discipline.
Do not embed sensitive server logic or private operational details into web assets.

🏛️🌿☠️══════════════════════════════════════════════════════════════☠️🌿🏛️
