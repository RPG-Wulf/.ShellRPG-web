Deutsch | [English](README.en.md)

🏛️☠️🌿                                                                 🌿☠️🏛️
╔══════════════════════════════════════════════════════════════════════════════╗
║  _/\______________________________________________________________/\\_     ║
║  \_/\\                                                            /\_/     ║
║  /_/\\   A U F G E R O L L T E   S C H R I F T R O L L E         /\_\     ║
║  \_\/____________________________________________________________\/_/     ║
╚══════════════════════════════════════════════════════════════════════════════╝
# ShellRPG-www · v0.6.7

## 1. Beschreibung

**Artefaktrolle:** Öffentlicher grafischer Web-Client für Karte, Bewegung, Charakterübersicht, Inventar, Stadt- und Systemansichten.

**Zweck:** Dieses Artefakt bietet die visuelle Schwesteroberfläche des Terminal-Clients. Es ist auf Übersicht, Navigation und systemnahe Bedienung ausgelegt, ohne die Serverautorität zu unterlaufen.

**Verknüpfte Artefakte:**
- `ShellRPG-server` liefert alle autoritativen Daten.
- `ShellRPG-client` ist der shellnahe Schwester-Client.
- `ShellRPG-wiki` liefert redigierte Dokumentation, Lore und Bedienhilfen.

**Governance:** `CLIENT-PUBLIC`

## 2. Abhängigkeiten

- statischer Webserver oder lokaler Datei-Host
- Browser mit modernem JavaScript-Support
- laufender `ShellRPG-server` für echte Daten

## 3. Installation

```bash
python -m http.server 8080
```

Dann im Browser öffnen:
```text
http://127.0.0.1:8080/public/index.html
```

## 4. Feedback & Contribution

Feedback sollte Browser, Auflösung und betroffene Ansicht nennen.
Contribution soll auf Zugänglichkeit, Lesbarkeit und Public-Scope achten.
Keine sensiblen Serverlogiken oder geheimen Betriebsdetails in Web-Assets einbetten.

🏛️🌿☠️══════════════════════════════════════════════════════════════☠️🌿🏛️
